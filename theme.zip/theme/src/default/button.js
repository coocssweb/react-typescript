/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-15 10:27:53
 * Copyright © Leedarson. All rights reserved.
 */
import { maskGray } from './color';

const btnDisabledFontColor = 'rgba(0,0,0,.18)';
const btnDisabledBg = '#fafafa';
// base
export const btnWidth = '150px';
export const btnHeight = '40px';
export const btnFontSize = '17px';
export const btnBorderRadius = '4px';
export const btnPaddingY = '8px';
export const btnPaddingX = '24px';
export const btnLineHeight = (40 - 18) / 17;

// small
export const btnSmallHeight = '32px';
export const btnSmallFontSize = '16px';
export const btnSmallBorderRadius = '3px';
export const btnSmallPaddingY = '0px';
export const btnSmallPaddingX = '18px';
export const btnSmallLineHeight = 2;

// default
export const btnDefaultBg = '#F2F2F2';
export const btnDefaultFontColor = '#06AE56';
export const btnDefaultActiveBg = '#D9D9D9';
export const btnDefaultActiveFontColor = '#06AE56';
export const btnDefaultDisabledFontColor = btnDisabledFontColor;
export const btnDefaultDisabledBg = btnDisabledBg;

// primary
export const btnPrimaryBg = '#07C160';
export const btnPrimaryFontColor = '#FFFFFF';
export const btnPrimaryActiveBg = '#06AD56';
export const btnPrimaryActiveFontColor = '#FFFFFF';
export const btnPrimaryDisabledFontColor = btnDisabledFontColor;
export const btnPrimaryDisabledBg = btnDisabledBg;

// warn
export const btnWarnBg = '#FA5151';
export const btnWarnFontColor = '#FFFFFF';
export const btnWarnActiveBg = '#E94040';
export const btnWarnActiveFontColor = '#FFFFFF';
export const btnWarnDisabledBg = btnDisabledBg;
export const btnWarnDisabledFontColor = btnDisabledFontColor;

// plan && default
export const btnPlainDefaultBorderColor = 'rgba(53,53,53,1)';
export const btnPlainDefaultColor = 'rgba(53,53,53,1)';
export const btnPlainDefaultActiveBgColor = maskGray;

// plan && primary
export const btnPlainPrimaryBorderColor = 'rgba(26,173,25,1)';
export const btnPlainPrimaryColor = '#07C160';
export const btnPlainPrimaryActiveBgColor = maskGray;

// plan && warn
export const btnPlainWarnBorderColor = 'rgba(250,81,81,1)';
export const btnPlainWarnColor = 'rgba(250,81,81,1)';
export const btnPlainWarnActiveBgColor = maskGray;

// plan && disable
export const btnPlainDisableBorderColor = 'rgba(0, 0, 0, 0.2)';
export const btnPlainDisableColor = 'rgba(0, 0, 0, 0.2)';
