/*
 * @Author =  wangjiaxin@leedarson.com
 * @Date =  2019-08-15 16 = 41 = 23
 * Copyright © Leedarson. All rights reserved.
 */
import { lineColorLight } from './color';

export const cellBg = '#FFFFFF';
export const cellBorderColor = lineColorLight;
export const cellPaddingY = '16px';
export const cellPaddingX = '16px';
export const cellInnerPadding = '16px';
export const cellHeight = '56px';
export const cellFontSize = '17px';
export const cellTipsFontSize = '14px';
export const cellLabelWidth = '105px';

export const cellLineHeight = `${(cellHeight - 2 * cellPaddingY) / cellFontSize}px`;
export const cellsMarginTop = '8px';
