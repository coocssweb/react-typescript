/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-14 19:27:05
 * Copyright © Leedarson. All rights reserved.
 */

import color from './color';

const name = 'linkind';
const bgLogin = require('./assets/bg-login.png');
const iconMail = require('./assets/icon-mail.png');
const iconPassword = require('./assets/icon-password.png');

export { bgLogin, iconMail, iconPassword, color, name };
