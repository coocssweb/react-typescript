/*
 * @Author: wangjiaxin@leedarson.com 
 * @Date: 2019-08-20 15:16:00 
 * @Last Modified by: wangjiaxin@leedarson.com
 * @Last Modified time: 2019-08-20 15:22:50
 */

export const zIndexMask = 5000;
export const zIndexModal = 5001;
export const zIndexTooltip = 5001;
export const zIndexToast = 5001;