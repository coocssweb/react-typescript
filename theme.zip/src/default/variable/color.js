/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-15 10:47:05
 * Copyright © Leedarson. All rights reserved.
 */

// basic
export const colorWhite = '#fff';
export const colorBlack = '#000';
export const colorDefault = '#484848';
export const colorPrimary = '#409eff';
export const colorSuccess = '#07C160';
export const colorWarn = '#e6a23c';
export const colorDanger = '#FA5151';

// background
export const bgColorDefault = '#EDEDED';
export const bgColorPrimary = '#F7F7F7';
export const bgColorActive = '#ECECEC';

// line
export const lineColorLight = 'rgba(0,0,0,.1)';
export const lineColorDark = 'rgba(0,0,0,.3)';

// article text
export const textColorTitle = '#303133';
export const textColorDesc = '#606266';
export const textColorTips = '#909399';
export const textColorPlaceholder = '#C0C4CC';
export const textColorWarn = colorWarn;

// active background color
export const activeBgColor = 'rgba(0,0,0, 0.05)';

// mask
export const maskWhite = 'rgba(255,255,255, .1)';
export const maskGray = 'rgba(0,0,0,.1)';
export const maskBlack = 'rgba(0,0,0,.6)';
