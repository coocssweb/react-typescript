/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-15 10:27:53
 * Copyright © Leedarson. All rights reserved.
 */

// gap, padding, margin间距，8的倍数
// 注意：数字类型，组件内会自动转为 px/rem/em
export const sizeGap = 16;
export const sizeGapSmall = 8;
export const sizeGapLarge = 24;

// border-radius，圆角
// 注意：数字类型，组件内会自动转为 px/rem/em
export const sizeRadius = 3;
export const sizeRadiusSmall = 2;
export const sizeRadiusLarge = 5;

// fontSize，字体大小
// 注意：数字类型，组件内会自动转为 px/rem/em
export const sizeFont = 17;
export const sizeFontSmall = 14;
export const sizeFontLarge = 22;

// lineHeight 行高
export const sizeLineHeight = 1.4;
export const sizeLineHeightSmall = 1.2;
