/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-15 10:27:53
 * Copyright © Leedarson. All rights reserved.
 */

import { colorToActive, colorToDisabled, colorToPlainActive } from '../colorMixer';
import { colorDefault, colorPrimary, colorSuccess, colorWarn, colorDanger } from './variable/color';
import * as size from './variable/size';

// base
export const btnWidth = 150;
export const btnHeight = 40;
export const btnFontSize = size.sizeFont;
export const btnBorderRadius = size.sizeRadius;
export const btnBorderRadiusRound = btnHeight / 2;
export const btnPaddingY = size.sizeGapSmall;
export const btnPaddingX = size.sizeGapLarge;
export const btnLineHeight = (btnHeight - 2 * btnPaddingY) / 17;

// small
export const btnSmallHeight = 32;
export const btnSmallFontSize = size.sizeFontSmall;
export const btnSmallBorderRadius = size.sizeRadiusSmall;
export const btnSmallBorderRadiusRound = btnSmallHeight / 2;
export const btnSmallPaddingY = 0;
export const btnSmallPaddingX = size.sizeGap;
export const btnSmallLineHeight = btnSmallHeight / btnSmallFontSize;

// active
export const colorDefaultActive = colorToActive(colorDefault);
export const colorPrimaryActive = colorToActive(colorPrimary);
export const colorSuccessActive = colorToActive(colorSuccess);
export const colorWarnActive = colorToActive(colorWarn);
export const colorDangerActive = colorToActive(colorDanger);

// disabled
export const colorDefaultDisabled = colorToDisabled(colorDefault);
export const colorPrimaryDisabled = colorToDisabled(colorPrimary);
export const colorSuccessDisabled = colorToDisabled(colorSuccess);
export const colorWarnDisabled = colorToDisabled(colorWarn);
export const colorDangerDisabled = colorToDisabled(colorDanger);

// plan && active
export const colorDefaultPlainActive = colorToPlainActive(colorDefault);
export const colorPrimaryPlainActive = colorToPlainActive(colorPrimary);
export const colorSuccessPlainActive = colorToPlainActive(colorSuccess);
export const colorWarnPlainActive = colorToPlainActive(colorWarn);
export const colorDangerPlainActive = colorToPlainActive(colorDanger);
