/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-15 10:27:53
 * Copyright © Leedarson. All rights reserved.
 */

import * as color from './variable/color';
import * as size from './variable/size';

export const cellBg = color.colorWhite;
export const cellBorderColor = color.lineColorLight;
export const cellPaddingY = size.sizeGap;
export const cellPaddingX = size.sizeGap;
export const cellInnerPadding = size.sizeGap;
export const cellHeight = 56;
export const cellFontSize = size.sizeFont;
export const cellTipsFontSize = size.sizeFontSmall;
export const cellLabelWidth = 90;

export const cellLineHeight = (cellHeight - 2 * cellPaddingY) / cellFontSize;
export const cellsMarginTop = size.sizeGap;
