/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-14 19:27:24
 * Copyright © Leedarson. All rights reserved.
 */

import * as Default from '../default';

export default Object.assign({}, Default);
