/* eslint-disable no-param-reassign */
/* eslint-disable no-multi-assign */
/* eslint-disable func-names */
/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-15 10:27:53
 * Copyright © Leedarson. All rights reserved.
 */

/**
 * hex 转为 rgb
 * #000000 => [0, 0, 0, 1]
 * @param {*} hex
 */
export const hexToRGB = hex => {
  const hex2rgb = h => {
    const decimal = parseInt(h, 16);
    return decimal;
  };

  return [hex2rgb(hex.substr(1, 2)), hex2rgb(hex.substr(3, 2)), hex2rgb(hex.substr(5, 2))].concat([1]);
};

/**
 * 未知类型 转为 rgb
 * rgba(0, 0, 0, 1) => [0, 0, 0, 1]
 * #000000 => [0, 0, 0, 1]
 * @param {*} value
 */
export const toRgb = value => {
  if (Array.isArray(value)) {
    return value;
  }
  if (value.includes('#')) {
    return hexToRGB(value);
  }

  const base = value
    .replace('rgba(', '')
    .replace('rgb(', '')
    .replace(')', '')
    .split(',');
  return base.map(d => d.trim());
};

/**
 * rgb => hex
 * rgba(0, 0, 0, 1) => #000000
 * [0, 0, 0] => #000000
 * @param {*} rgba
 */
export const rgbToHEX = value => {
  const rgb = toRgb(value).slice(0, 3);
  const rgb2hex = d => {
    let hex = d.toString(16);
    hex = '00'.substr(0, 2 - hex.length) + hex;
    return hex;
  };

  return `#${rgb
    .map(rgb2hex)
    .join('')
    .toLowerCase()}`;
};

/**
 * rgb 转为 hsl
 * [0, 0, 0, 1] => [0%, 0%, 0%, 1]
 * @param {*} rgba
 */
export const rgbToHSL = rgba => {
  const r = rgba[0] / 255;
  const g = rgba[1] / 255;
  const b = rgba[2] / 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h;
  let s;
  const l = (max + min) / 2;
  const d = max - min;
  const huecalc = {};
  huecalc[r] = function() {
    return (60 * (g - b)) / d + (g < b ? 360 : 0);
  };
  huecalc[g] = function() {
    return (60 * (b - r)) / d + 120;
  };
  huecalc[b] = function() {
    return (60 * (r - g)) / d + 240;
  };
  if (d === 0) {
    h = s = 0;
  } else {
    s = l < 0.5 ? d / (max + min) : d / (2 - max - min);
    h = huecalc[String(max)]();
  }
  return [Math.round(h), Math.round(s * 100), Math.round(l * 100)].concat([rgba[3]]);
};

/**
 * hsl 转为 rgb
 * [0%, 0%, 0%, 1] => [0, 0, 0, 1]
 * @param {*} hsla
 */
export const hslToRGB = hsla => {
  let r;
  let g;
  let b;
  const h = hsla[0] / 360;
  const s = hsla[1] / 100;
  const l = hsla[2] / 100;

  const hue2rgb = (p, q, t) => {
    if (t < 0) t += 1;
    if (t > 1) t -= 1;
    if (t < 1 / 6) return p + (q - p) * 6 * t;
    if (t < 1 / 2) return q;
    if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
    return p;
  };

  if (s === 0) {
    r = g = b = l;
  } else {
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r = hue2rgb(p, q, h + 1 / 3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1 / 3);
  }
  return [r, g, b]
    .map(function(c) {
      return Math.round(c * 255);
    })
    .concat([hsla[3]]);
};

/**
 * 混合两种颜色
 * @param {*} colorA
 * @param {*} colorB
 * @param {*} weight
 */
export const mix = (colorA, colorB, weight = 10) => {
  const base = toRgb(colorB);
  const brend = toRgb(colorA);
  const newColor = base.map((c, i) => {
    if (i === 3) {
      return brend[i] + (c - brend[i]) * (weight / 100);
    }
    return Math.floor(brend[i] + (c - brend[i]) * (weight / 100));
  });
  return `rgba(${newColor})`;
};

/**
 * 颜色 转为 :active状态颜色
 * @param {*} color
 */
export const colorToActive = color => {
  return mix(color, 'rgba(0, 0, 0, 1)', 20);
};

/**
 * 颜色 转为 :disable状态颜色
 * @param {*} color
 */
export const colorToDisabled = color => {
  return mix(color, 'rgba(255, 255, 255, 1)', 50);
};

/**
 * 颜色 转为 :plain && :active状态颜色
 * @param {*} color
 */
export const colorToPlainActive = color => {
  const rgb = toRgb(color).slice(0, 3);
  rgb.push(0.2);

  return `rgba(${rgb})`;
};
