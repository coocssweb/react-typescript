/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-14 19:27:05
 * Copyright © Leedarson. All rights reserved.
 */
import * as Default from '../default';

const name = 'linkind';
const bgLogin = require('./assets/bg-login.png');
const iconMail = require('./assets/icon-mail.png');
const iconPassword = require('./assets/icon-password.png');

export default Object.assign({}, Default, {
  bgLogin,
  iconMail,
  iconPassword,
  name,
});
