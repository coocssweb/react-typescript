# `@leedarson/new-component`

## 样式编码规范

- ✔︎ 可配置多环境，开发环境、测试环境、预生产环境、生产环境等
- ✔︎ 可自定义配置多入口，简易配置，入口和入口间相互独立
- ✔︎ 拥有许多通用模块，让你从繁杂的网页开发中跳出来
- ✔︎ 基于 Typescript 实现，让你的 Javascript 代码更好维护
- ✔ 无第三方依赖，代码体积小，如果你需要其他依赖可自行引入
- ✔ 支持响应式开发

## 组件列表

```bash
    // done: ✔︎ , doing: - , plan: *
    ├──Button                       ✔︎ 按钮组件
    ├──Input                        ✔︎ 输入框组件
    ├──Cells                        ✔︎ 项目代码目录
    ├──Flex                         ✔︎ Flex组件
    ├──Loading                      ✔︎ Loading组件
    ├──Mask                         ✔︎ Mask蒙层组件
    ├──WhiteSpace                   ✔︎ 上下间距
    ├──WingBlank                    ✔︎ 两侧空白
    ├──Slider                       - 滑块
    ├──Sortable                     - 排序组件
    ├──RgbwSlider                   - RgbwSlider
    ├──CctSlider                    - CctSlider
    ├──Pop                          * PopUp，Pop弹出框
    ├──Modal                        * Modal，Modal对话框
    ├──Tab                          * Tab
    ├──TabPage                      * TabPage 页面Tab
    ├──Toast                        * Toast，提示框
    ├──Switch                       * Switch 开关
    ├──Radio                        * Radio 单选
    ├──Checkbox                     * Checkbox 单选
    ├──Progress                     * Progress 进度条(建议：应支持圆形和条状的)
    ├──Badge                        * Progress 徽章
    ├──Text                         * Text 输入框
    ├──Empty                        * Empty 空省（建议：包含各个列表数据的Empty）
    ├──Icon                         * Icon Icon
    ├──Dropdown                     * Dropdown 下拉框
    ├──LazyImage                    - Lazy 懒加载图片
    ├──LoadMore                     - LoadMore（建议：应支持未开始，加载中，没有更多等状态）
    ├──LoadMore                     - LoadMore（建议：应支持未开始，加载中，没有更多等状态）
```
