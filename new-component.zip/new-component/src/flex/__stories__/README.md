# Flex

Flex 布局

## Flex 属性说明

## FlexItem 属性说明

| 属性 | 说明      | 类型   | 默认值 |
| ---- | --------- | ------ | ------ |
| flex | flex 占位 | number | 1      |
