import styled, { css } from 'styled-components';

// mask风格, ['transparent', 'white', 'black']
const maskType = {
  transparent: () => css`
    background: rgba(255, 255, 255, 0);
  `,
  white: props => css`
    background: ${props.theme.maskWhite};
  `,
  black: props => css`
    background: ${props.theme.maskBlack};
  `,
};

const StyledMask = styled.div`
  position: fixed;
  z-index: 1;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  ${props => maskType[props.type](props)}
`;

export default StyledMask;
