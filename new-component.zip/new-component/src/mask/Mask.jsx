/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-15 11:02:59
 * Copyright © Leedarson. All rights reserved.
 */

import React from 'react';
import PropTypes from 'prop-types';
import StyledMask from './StyledMask';

const Mask = ({ type, onClick }) => {
  return <StyledMask type={type} onClick={onClick} />;
};

Mask.defaultProps = {
  type: 'black',
  onClick: () => {},
};

Mask.propTypes = {
  type: PropTypes.oneOf(['transparent', 'black', 'white']),
  onClick: PropTypes.func,
};

export default Mask;
