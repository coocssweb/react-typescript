import Mask from './Mask';

export default Mask;
