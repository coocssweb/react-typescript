import WingBlank from './WingBlank';

export default WingBlank;
