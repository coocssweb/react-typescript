# Loading

加载中说明

## 属性说明

| 属性  | 说明                                  | 类型   | 默认值 |
| ----- | ------------------------------------- | ------ | ------ |
| color | loading 颜色                          | string | #fff   |
| size  | loading 大小，可选值为`large`/`small` | string | large  |

## 全局方法

```bash
$loading.show();

// TODO
$loading.spin();
```
