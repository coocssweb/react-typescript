/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-15 19:17:01
 * Copyright © Leedarson. All rights reserved.
 */

import React from 'react';
import { ThemeProvider } from 'styled-components';
import { themeDefault } from '@leedarson/theme';
import { Loading, Button } from '../../index';

const Demo = () => {
  const handleShowLoadingClick = (color) => () => {
    window.$loading.show({color});
  };

  return (
    <ThemeProvider theme={themeDefault}>
      <div className="demo">
        <div className="demo-title">Loading 行内引用 </div>
        <div className="demo-box">
          <Loading />
        </div>

        <div className="demo-title">Loading 全局方法 </div>
        <div className="demo-box">
          <Button onClick={handleShowLoadingClick(themeDefault.colorSuccess)}>$loading.show</Button>
        </div>
      </div>
    </ThemeProvider>
  );
};

export default Demo;
