import styled, { keyframes, css } from 'styled-components';

// Loading animation keyframes
const LoadingSpan = keyframes`
  0%,
  80%,
  100% {
    opacity: 0;
    transform: scale(0);
  }

  30%,
  50% {
    opacity: 1;
    transform: scale(1);
  }
`;

// Loading mask
const loadingMask = css`
  display: flex;
  height: 80px;
  width: 80px;
  background-color: #ffffff;
  align-items: center;
  justify-content: center;
  position: relative;
  border-radius: 4px;
  z-index: 2;
`;

// Loading container
const StyledLoading = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 0;
  height: 100%;
  ${props => css`
    ${props.mask && loadingMask}
  `}
`;

// Loading Item
// TODO: background 替换成theme
const StyledLoadingItem = styled.span`
  display: inline-block;
  width: 8px;
  height: 8px;
  margin-right: ${props => (props.last ? `0px` : `8px`)};
  border-radius: 4px;
  background: ${props => props.color};
  animation-name: ${LoadingSpan};
  animation-duration: 0.9s;
  animation-iteration-count: infinite;
  animation-timing-function: linear;
  animation-fill-mode: both;
  animation-delay: ${props => props.delay};
`;

export { StyledLoading, StyledLoadingItem };
