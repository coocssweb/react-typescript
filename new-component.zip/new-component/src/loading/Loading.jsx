import React from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';
import Mask from '../mask';
import { StyledLoading, StyledLoadingItem } from './StyledLoading';

const Loading = ({ color, size, mask }) => {
  return (
    <>
      {mask ? <Mask /> : null}
      <StyledLoading mask={mask}>
        <StyledLoadingItem key="1" delay="-.3s" color={color} size={size} />
        <StyledLoadingItem key="2" delay="-0.15s" color={color} size={size} />
        <StyledLoadingItem key="3" last delay="0s" color={color} size={size} />
      </StyledLoading>
    </>
  );
};

Loading.defaultProps = {
  size: 'large',
  color: '#ffffff',
  mask: false,
};

Loading.propTypes = {
  color: PropTypes.string,
  size: PropTypes.oneOf(['small', 'large']),
  mask: PropTypes.bool,
};

// 延迟、持续定时器
Loading.delayTimer = null;
Loading.durationTimer = null;

// Loading 销毁方法
Loading.destroy = () => {
  if (Loading.delayTimer) {
    clearTimeout(Loading.delayTimer);
  }
  if (Loading.durationTimer) {
    clearTimeout(Loading.durationTimer);
  }
  if (Loading.instance && Loading.instance.destroy) {
    Loading.instance.destroy();
    Loading.instance = null;
  }
};

const newInstance = (duration, color, mask, fn) => {
  const loadingRoot = document.createElement('div');
  loadingRoot.className = 'loading-container';
  Loading.domContainer = loadingRoot;
  document.body.appendChild(loadingRoot);

  if (duration) {
    Loading.durationTimer = setTimeout(() => {
      Loading.destroy();
    }, duration);
  }

  fn({
    destroy() {
      // 移除loading-container 时，主动销毁组件
      ReactDOM.unmountComponentAtNode(loadingRoot);
      document.body.removeChild(loadingRoot);
    },
  });

  ReactDOM.render(<Loading color={color} mask />, loadingRoot);
};

// 先支持show方法
// TODO，以后支持Bubbles， Spin， Bars等方法
Loading.show = ({delay = 0, duration = 2000, mask = true, color}) => {
  if (!Loading.instance) {
    if (delay) {
      Loading.delayTimer = setTimeout(() => {
        newInstance(duration, color, mask, instance => {
          Loading.instance = instance;
        });
      }, delay);
      return;
    }

    newInstance(duration, color, mask, instance => {
      Loading.instance = instance;
    });
  }
};

window.$loading = Loading;

export default Loading;
