# WhiteSpace

上下距离，用于替换元素的 marginTop/marginBottom 写法，最终的计算时 size \* 8px

## 属性说明

| 属性 | 说明 | 类型   | 默认值 |
| ---- | ---- | ------ | ------ |
| size | 大小 | number | 1      |
