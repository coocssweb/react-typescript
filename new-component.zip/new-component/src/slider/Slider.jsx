import RcSlider from 'rc-slider';
import React from 'react';
import PropTypes from 'prop-types';

const Slider = ({ type, onClick }) => {
  return <StyledMask type={type} onClick={onClick} />;
};

Slider.defaultProps = {
  type: 'black',
  onClick: () => {},
};

Slider.propTypes = {
  min: PropTypes.number,
  max: PropTypes.number,
};

export default Slider;
