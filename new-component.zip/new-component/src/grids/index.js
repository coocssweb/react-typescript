import Grids from './Grids';
import GridItem from './GridItem';

Grids.GridItem = GridItem;

export default Grids;
