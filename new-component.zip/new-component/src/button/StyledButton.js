import styled, { css } from 'styled-components';

// 按钮大小 ['small', 'large']
const btnSize = {
  small: props => css`
    display: inline-block;
    width: auto;
    height: ${props.theme.btnSmallHeight};
    padding: ${props.theme.btnSmallPaddingY} ${props.theme.btnSmallPaddingX};
    font-size: ${props.theme.btnSmallFontSize};
    line-height: ${props.theme.btnSmallLineHeight};
    border-radius: ${props.theme.btnSmallBorderRadius};
  `,
  large: props => css`
    padding: ${props.theme.btnPaddingY} ${props.theme.btnPaddingX};
    width: ${props.block ? 'auto' : props.theme.btnWidth};
    height: ${props.theme.btnHeight};
    font-size: ${props.theme.btnFontSize};
    line-height: ${props.theme.btnLineHeight};
    border-radius: ${props.theme.btnBorderRadius};
  `,
};

// 按钮风格, ['default', 'primary', 'warn']
const btnType = {
  default: props => css`
    background: ${props.theme.btnDefaultBg};
    color: ${props.theme.btnDefaultFontColor};

    &:active {
      background: ${props.theme.btnDefaultActiveBg};
      color: ${props.theme.btnDefaultActiveFontColor};
    }
  `,
  primary: props => css`
    background: ${props.theme.btnPrimaryBg};
    color: ${props.theme.btnPrimaryFontColor};

    &:active {
      background: ${props.theme.btnPrimaryActiveBg};
      color: ${props.theme.btnPrimaryActiveFontColor};
    }
  `,
  warn: props => css`
    background: ${props.theme.btnWarnBg};
    color: ${props.theme.btnWarnFontColor};

    &:active {
      background: ${props.theme.btnWarnActiveBg};
      color: ${props.theme.btnWarnActiveFontColor};
    }
  `,
};

// plain: true 扁平化
const btnPlain = {
  default: props => css`
    border: 1px solid ${props.theme.btnPlainDefaultBorderColor};
    color: ${props.theme.btnPlainDefaultColor};
    &:active {
      background: ${props.theme.btnPlainDefaultActiveBgColor};
    }
  `,
  primary: props => css`
    border: 1px solid ${props.theme.btnPlainPrimaryBorderColor};
    color: ${props.theme.btnPlainPrimaryColor};
    &:active {
      background: ${props.theme.btnPlainPrimaryActiveBgColor};
    }
  `,
  warn: props => css`
    border: 1px solid ${props.theme.btnPlainWarnBorderColor};
    color: ${props.theme.btnPlainWarnColor};
    &:active {
      background: ${props.theme.btnPlainWarnActiveBgColor};
    }
  `,
};

// 禁用状态
const btnDisabledType = {
  default: props => css`
    background: ${props.theme.btnDefaultDisabledBg};
    color: ${props.theme.btnDefaultDisabledFontColor};
  `,
  primary: props => css`
    background: ${props.theme.btnPrimaryBg};
    color: ${props.theme.btnPrimaryFontColor};
  `,
  warn: props => css`
    background: ${props.theme.btnWarnBg};
    color: ${props.theme.btnWarnFontColor};
  `,
};

// 扁平化禁用状态
const btnDisabledPlain = {
  default: props => css`
    color: ${props.theme.btnPlainDisableColor};
    border: 1px solid ${props.theme.btnPlainDisableBorderColor};
  `,
  primary: props => css`
    color: ${props.theme.btnPlainDisableColor};
    border: 1px solid ${props.theme.btnPlainDisableBorderColor};
  `,
  warn: props => css`
    color: ${props.theme.btnPlainDisableColor};
    border: 1px solid ${props.theme.btnPlainDisableBorderColor};
  `,
};

const StyledButton = styled.a`
  display: block;
  box-sizing: border-box;
  margin-left: auto;
  margin-right: auto;
  max-width: 100%;
  font-weight: 400;
  text-align: center;
  text-decoration: none;
  user-select: none;
  overflow: hidden;
  transition: all 0.2s ease;
  position: relative;
  ${props => css`
    ${btnSize[props.size](props)}
    ${!props.plain && !props.disabled && btnType[props.type](props)}
    ${props.plain && !props.disabled && btnPlain[props.type](props)}
    ${props.disabled && !props.plain && btnDisabledType[props.type](props)}
    ${props.disabled && props.plain && btnDisabledPlain[props.type](props)}
  `}
`;

export default StyledButton;
