/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-15 19:17:01
 * Copyright © Leedarson. All rights reserved.
 */

import React from 'react';
import { ThemeProvider } from 'styled-components';
import { themeDefault } from '@leedarson/theme';
import { Button } from '../../index';

const Demo = () => {
  const handleOnClick = () => {
    // something todo
  };

  return (
    <ThemeProvider theme={themeDefault}>
      <div className="demo">
        <div className="demo-title">Button Small</div>
        <div className="demo-box">
          <Button size="small">按钮</Button>
          <Button size="small" type="primary">
            按钮
          </Button>
          <Button size="small" type="warn">
            按钮
          </Button>
          <Button size="small" type="primary" loading>
            按钮
          </Button>
        </div>

        <div className="demo-title">Button Large</div>
        <div className="demo-box">
          <Button onClick={handleOnClick}>按钮</Button>
          <div className="demo-split" />
          <Button type="primary">按钮</Button>
          <div className="demo-split" />
          <Button type="primary" loading>
            加载中
          </Button>
          <div className="demo-split" />
          <Button type="warn">按钮</Button>
          <div className="demo-split" />
          <Button type="warn" loading>
            加载中
          </Button>
          <div className="demo-split" />
          <Button disabled>按钮禁用</Button>
        </div>

        <div className="demo-title">Button Plain</div>
        <div className="demo-box">
          <Button plain>按钮</Button>
          <div className="demo-split" />
          <Button plain loading>
            按钮
          </Button>
          <div className="demo-split" />
          <Button plain type="primary">
            按钮
          </Button>
          <div className="demo-split" />
          <Button plain type="primary" loading>
            按钮
          </Button>
          <div className="demo-split" />
          <Button plain type="warn">
            按钮
          </Button>
          <div className="demo-split" />
          <Button plain type="warn" loading>
            按钮
          </Button>
          <div className="demo-split" />
          <Button plain disabled>
            按钮禁用
          </Button>
        </div>

        <div className="demo-title">Button Block</div>
        <div className="demo-box">
          <Button block>页面主操作</Button>
          <div className="demo-split" />
          <Button type="primary" block>
            页面主操作
          </Button>
          <div className="demo-split" />
          <Button type="warn" block>
            页面主操作
          </Button>
        </div>
      </div>
    </ThemeProvider>
  );
};

export default Demo;
