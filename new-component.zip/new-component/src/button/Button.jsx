import React, { useMemo } from 'react';
import PropTypes from 'prop-types';
import { withTheme } from 'styled-components';
import StyledButton from './StyledButton';
import Loading from '../loading';

const Button = props => {
  const { children, type, size, block, disabled, loading, plain, theme, onClick } = props;

  // loading 状态, loading的颜色
  const loadingColor = useMemo(() => {
    let color = theme.white;
    if (plain) {
      switch (type) {
        case 'default':
          color = theme.btnPlainDefaultColor;
          break;
        case 'primary':
          color = theme.btnPlainPrimaryColor;
          break;
        case 'warn':
          color = theme.btnPlainWarnColor;
          break;
        default:
          color = theme.white;
      }
    }
    return color;
  }, [plain, theme.btnPlainDefaultColor, theme.btnPlainPrimaryColor, theme.btnPlainWarnColor, theme.white, type]);

  return (
    <StyledButton
      type={type}
      size={size}
      block={block}
      disabled={disabled}
      loading={loading}
      plain={plain}
      onClick={onClick}
    >
      {loading ? <Loading color={loadingColor} /> : children}
    </StyledButton>
  );
};

Button.defaultProps = {
  type: 'default',
  size: 'large',
  block: false,
  disabled: false,
  loading: false,
  plain: false,
  theme: {},
  onClick: () => {},
};

Button.propTypes = {
  type: PropTypes.oneOfType(['default', 'primary', 'warn']),
  size: PropTypes.oneOfType(['small', 'large']),
  block: PropTypes.bool,
  disabled: PropTypes.bool,
  loading: PropTypes.bool,
  plain: PropTypes.bool,
  // eslint-disable-next-line react/forbid-prop-types
  theme: PropTypes.object,
  onClick: PropTypes.func,
  children: PropTypes.node.isRequired,
};

export default withTheme(Button);
