import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';

const StyledCellLabel = styled.div`
  display: block;
  width: ${props => props.cellLabelWidth};
`;

const CellLabel = props => {
  const { children } = props;

  return <StyledCellLabel>{children}</StyledCellLabel>;
};

CellLabel.propTypes = {
  children: PropTypes.node.isRequired,
};

export default CellLabel;
