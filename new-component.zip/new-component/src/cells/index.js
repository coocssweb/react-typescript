/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-14 17:45:21
 * Copyright © Leedarson. All rights reserved.
 */
import Cells from './Cells';
import CellsTitle from './CellsTitle';
import CellsTips from './CellsTips';
import CellItem from './CellItem';
import CellHeader from './CellHeader';
import CellBody from './CellBody';
import CellFooter from './CellFooter';

Cells.CellsTitle = CellsTitle;
Cells.CellsTips = CellsTips;
Cells.CellItem = CellItem;
Cells.CellHeader = CellHeader;
Cells.CellBody = CellBody;
Cells.CellFooter = CellFooter;

export default Cells;
