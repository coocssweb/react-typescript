import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { setTopLine } from '../styled-engine/setOnePx';

const StyledCellItem = styled.div`
  padding: 16px;
  position: relative;
  display: flex;
  align-items: center;
  &:before {
    ${setTopLine()}
    left:16px;
    z-index: 2;
  }
  &:first-child {
    &:before {
      display: none;
    }
  }
`;

const CellItem = ({ children }) => {
  return <StyledCellItem>{children}</StyledCellItem>;
};

CellItem.propTypes = {
  children: PropTypes.node.isRequired,
};

export default CellItem;
