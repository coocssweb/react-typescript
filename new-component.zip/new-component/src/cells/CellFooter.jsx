import React from 'react';
import PropTypes from 'prop-types';
import styled, { css } from 'styled-components';
import { setRightArrow } from '../styled-engine';

const cellFooterArrow = css`
  padding-right: 16px;
  ${setRightArrow('8px', '#b2b2b2', '2px')}
`;

const StyledCellFooter = styled.div`
  text-align: right;
  color: ${props => props.textColorDesc};
  position: relative;
  ${props => css`
    ${props.arrow && cellFooterArrow()}
  `}
`;

const CellFooter = props => {
  const { children, arrow } = props;
  return <StyledCellFooter arrow={arrow}>{children}</StyledCellFooter>;
};

CellFooter.defaultProps = {
  arrow: false,
};

CellFooter.propTypes = {
  children: PropTypes.node.isRequired,
  arrow: PropTypes.bool,
};

export default CellFooter;
