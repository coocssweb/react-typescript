/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-21 11:44:15
 * Copyright © Leedarson. All rights reserved.
 */
import Icon from './Icon';

export default Icon;
