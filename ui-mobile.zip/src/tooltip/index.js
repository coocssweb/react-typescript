/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-21 12:10:24
 * Copyright © Leedarson. All rights reserved.
 */

import Tooltip from './Tooltip';

export default Tooltip;
