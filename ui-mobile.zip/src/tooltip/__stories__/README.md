# Slider

滑块

## 属性说明

| 属性           | 说明     | 类型                      | 默认值  |
| -------------- | -------- | ------------------------- | ------- |
| defaultVisible | 默认可见 | boolean                   | false   |
| placement      | 位置     | `top`, `bottom`           | `top`   |
| value          | 默认值   | string/number             | null    |
| trigger        | 触发方式 | `hover`, `focus`, `click` | `focus` |
