/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-15 11:21:32
 * Copyright © Leedarson. All rights reserved.
 */

import Flex from './Flex';
import FlexItem from './FlexItem';

Flex.FlexItem = FlexItem;

export default Flex;
