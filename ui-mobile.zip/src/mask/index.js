/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-21 12:06:24
 * Copyright © Leedarson. All rights reserved.
 */

import Mask from './Mask';

export default Mask;
