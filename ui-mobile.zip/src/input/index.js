/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-21 12:05:52
 * Copyright © Leedarson. All rights reserved.
 */

import Input from './Input';

export default Input;
