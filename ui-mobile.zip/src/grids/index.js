/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-21 11:44:00
 * Copyright © Leedarson. All rights reserved.
 */

import Grids from './Grids';
import GridItem from './GridItem';

Grids.GridItem = GridItem;

export default Grids;
