/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-22 14:22:15
 * Copyright © Leedarson. All rights reserved.
 */
import Progress from './Progress';

export default Progress;
