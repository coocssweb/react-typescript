# TabPage

TabPage 布局，包含三个子组件 TabPanel,TabBar,TabBarItem。服务于主页/栏目级别的页面

## TabPage

布局框，无属性需求

## TabPanel

TabPage 的内容面板，无属性需求

## TabBar

TabPage 的导航条，无属性需求

## TabBarItem 属性说明

| 属性 | 说明      | 类型   | 默认值 |
| ---- | --------- | ------ | ------ |
| icon | icon 图标 | string | ''     |
| link | 链接      | string | ''     |
