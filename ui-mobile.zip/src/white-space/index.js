/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-21 12:11:19
 * Copyright © Leedarson. All rights reserved.
 */

import WhiteSpace from './WhiteSpace';

export default WhiteSpace;
