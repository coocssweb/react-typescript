/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-21 11:43:08
 * Copyright © Leedarson. All rights reserved.
 */
import Button from './Button';

export default Button;
