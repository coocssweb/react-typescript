/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-20 15:48:55
 * Copyright © Leedarson. All rights reserved.
 */
import Toast from './Toast';

export default Toast;
