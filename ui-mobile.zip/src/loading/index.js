/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-16 09:03:41
 * Copyright © Leedarson. All rights reserved.
 */

import Loading from './Loading';

export default Loading;
