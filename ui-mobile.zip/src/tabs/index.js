/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-21 12:07:57
 * Copyright © Leedarson. All rights reserved.
 */

import Tabs from './Tabs';

export default Tabs;
