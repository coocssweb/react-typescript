# WingBlank

两边距离，用于替换块元素的 marginLeft，marginRight 的写法，最终的计算时 size \* 8px

## 属性说明

| 属性 | 说明 | 类型   | 默认值 |
| ---- | ---- | ------ | ------ |
| size | 大小 | number | 1      |
