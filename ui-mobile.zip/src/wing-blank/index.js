/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-21 12:11:28
 * Copyright © Leedarson. All rights reserved.
 */

import WingBlank from './WingBlank';

export default WingBlank;
